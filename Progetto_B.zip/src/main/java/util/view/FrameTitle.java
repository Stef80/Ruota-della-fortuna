package util.view;

/**
 * Questa classe ha lo scopo di standardizzare il titolo delle finestra utilizzate nel progetto
 */
public class FrameTitle {
    /**
     * Titolo principale, abbreviazione di Ruota della Fortuna
     */
    public static String main = "RdF";
}
